package com.blueprint.patterns.buschmann.design.command_processor;

public interface AbstractCommand
{
}