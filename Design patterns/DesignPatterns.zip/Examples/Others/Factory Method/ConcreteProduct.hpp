#include<Product.cpp>
class ConcreteProduct : public Product
{
}
