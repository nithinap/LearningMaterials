#include<iostream>
using namespace std;
int main( )
{
    LoginUser::login("Temp1", "T001");
    LoginUser::login("Temp2", "T002");
    LoginUser::login("Temp3", "T003");
    LoginUser::login("Temp4", "T004");
}
