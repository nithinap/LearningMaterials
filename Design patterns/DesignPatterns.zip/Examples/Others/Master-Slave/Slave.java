package com.blueprint.patterns.buschmann.design.master_slave;

public interface Slave
{
}